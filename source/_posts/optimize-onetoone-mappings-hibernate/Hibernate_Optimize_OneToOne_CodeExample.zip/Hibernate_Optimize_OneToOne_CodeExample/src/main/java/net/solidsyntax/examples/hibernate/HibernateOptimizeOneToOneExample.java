package net.solidsyntax.examples.hibernate;

import net.solidsyntax.examples.hibernate.model.BonusCard;
import net.solidsyntax.examples.hibernate.model.ContactPerson;
import net.solidsyntax.examples.hibernate.model.Customer;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HibernateOptimizeOneToOneExample {

    private SessionFactory sessionFactory;

    public static void main(String[] args) {
        HibernateOptimizeOneToOneExample example = new HibernateOptimizeOneToOneExample();
        example.run();
    }

    private void run() {
        configureHibernate();
        insertTestData();
        loadCustomerAndfetchCardAndContactPerson();
    }

    private void configureHibernate() {
        Configuration configuration = new Configuration();
        configuration.addAnnotatedClass(Customer.class);
        configuration.addAnnotatedClass(ContactPerson.class);
        configuration.addAnnotatedClass(BonusCard.class);
        configuration.configure();
        ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
        sessionFactory = configuration.buildSessionFactory(serviceRegistry);
    }

    private void insertTestData() {
        Session session = sessionFactory.openSession();
        
       System.out.println("Insert example data");
        BonusCard bonusCard = new BonusCard();
        bonusCard.setCardCode("card_Code");
        
        
        Customer customer = new Customer();
        customer.setName("Customer name");
        customer.setBonusCard(bonusCard);

        ContactPerson contactPerson = new ContactPerson();
        contactPerson.setName("contact_person_name");
        contactPerson.setCustomer(customer);
        customer.setContactPerson(contactPerson);
                
        session.persist(bonusCard);
        session.persist(customer);
        session.persist(contactPerson);
        session.flush();
        session.close();
                
    }

    private void loadCustomerAndfetchCardAndContactPerson() throws HibernateException {
        Session session = sessionFactory.openSession();

        System.out.println("Load a single customer:");
        Criteria crit = session.createCriteria(Customer.class);
        @SuppressWarnings("unchecked")
        Customer customer = (Customer) crit.setMaxResults(1).uniqueResult();

        System.out.println("Fetch bonus card");
        BonusCard bonusCard = customer.getBonusCard();
        System.out.println("Bonus card code:  " + bonusCard.getCardCode());

        System.out.println("Fetch contact person");
        ContactPerson contactPerson = customer.getContactPerson();
        System.out.println("Contact person name:  " + contactPerson.getName());
        
        session.close();
    }

}
